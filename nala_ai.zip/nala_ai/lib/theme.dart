import 'package:flutter/material.dart';

class NalaColors {
  static const bg = Color(0xFF1B1F3B); // midnight
  static const surface = Color(0xFF262B52); // bubble Nala
  static const code = Color(0xFF12152B); // blok kode
  static const amber = Color(0xFFFFC857); // aksen (warna hoodie Nala)
  static const text = Color(0xFFE6E4FF);
  static const muted = Color(0xFF9A98C9);
  static const glow = Color(0xFF38BDF8); // biru neon dari headphone Nala
}

import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart';

import 'claude_client.dart';
import 'emotion.dart';
import 'llm.dart';
import 'local_llm.dart';
import 'nala_avatar.dart';
import 'settings.dart';
import 'settings_screen.dart';
import 'theme.dart';
import 'voice.dart';

const _historyKey = 'chat_history';
const _greeting =
    'Hai, aku Nala. Lagi ngerjain apa? Kirim kode, error, atau ide kamu, kita bahas bareng.';

/// Satu sumber jawaban: model di HP atau Claude.
class _Backend {
  _Backend(this.name, this.stream);
  final String name;
  final Stream<String> Function(List<ChatTurn> history, void Function(int) onRetry)
      stream;
}

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _input = TextEditingController();
  final _scroll = ScrollController();
  final List<ChatTurn> _turns = [];
  final _voice = NalaVoice.instance;
  final _stt = SpeechToText();

  AppSettings? _settings;
  bool _loading = false;
  bool _started = false; // jawaban sudah mulai muncul
  bool _stop = false;
  bool _listening = false;
  bool _sttReady = false;
  String? _note;
  String? _activeName;
  Emotion _emotion = Emotion.kalem;
  Timer? _pokeTimer;

  @override
  void initState() {
    super.initState();
    _voice.speaking.addListener(_onSpeaking);
    _loadSettings();
    _loadHistory();
    _voice.init().then((_) {
      if (mounted && !_voice.languageOk) {
        _toast(
            'Suara bahasa Indonesia belum terpasang di HP. Lihat petunjuknya di Pengaturan.');
      }
    });
  }

  @override
  void dispose() {
    _voice.speaking.removeListener(_onSpeaking);
    _voice.stop();
    _stt.cancel();
    _pokeTimer?.cancel();
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _onSpeaking() {
    if (mounted) setState(() {});
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg)));
  }

  // ---------- pengaturan & penyimpanan ----------

  Future<void> _loadSettings() async {
    final s = await SettingsStore.load();
    if (!mounted) return;
    setState(() => _settings = s);
    _applyVoice(s);
    if (_backends(s).isEmpty) _openSettings();
  }

  void _applyVoice(AppSettings s) {
    _voice.configure(enabled: s.voiceOn, rate: s.voiceRate, pitch: s.voicePitch);
  }

  Future<void> _openSettings() async {
    final s = _settings ?? await SettingsStore.load();
    if (!mounted) return;
    await _voice.stop();
    await Navigator.of(context).push<AppSettings>(
      MaterialPageRoute(builder: (_) => SettingsScreen(settings: s)),
    );
    final fresh = await SettingsStore.load();
    if (!mounted) return;
    setState(() => _settings = fresh);
    _applyVoice(fresh);
  }

  Future<void> _toggleVoice() async {
    final s = _settings;
    if (s == null) return;
    final next = s.copyWith(voiceOn: !s.voiceOn);
    setState(() => _settings = next);
    _applyVoice(next);
    await SettingsStore.save(next);
    _toast(next.voiceOn ? 'Suara Nala nyala' : 'Suara Nala mati');
  }

  Future<void> _loadHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_historyKey);
    if (raw == null || !mounted) return;
    try {
      final list = (jsonDecode(raw) as List)
          .map((e) => ChatTurn.fromJson(e as Map<String, dynamic>))
          .toList();
      setState(() => _turns.addAll(list));
      _jump();
    } catch (_) {
      // riwayat rusak, abaikan
    }
  }

  Future<void> _saveHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final data = _turns.where((t) => !t.isError).map((t) => t.toJson()).toList();
    await prefs.setString(_historyKey, jsonEncode(data));
  }

  /// Urutan sumber jawaban. Kalau pilih Claude, model di HP jadi cadangan.
  List<_Backend> _backends(AppSettings s) {
    final localSpec = localModelById(s.installedLocalId);
    final local = localSpec == null
        ? null
        : _Backend(
            localSpec.name,
            (h, _) => LocalLlm.instance.stream(h, useGpu: s.useGpu),
          );
    final claude = s.claudeReady
        ? _Backend(
            'Claude',
            (h, onRetry) => streamClaude(
              apiKey: s.claudeKey,
              model: s.claudeModel,
              history: h,
              onRetry: onRetry,
            ),
          )
        : null;
    if (s.engine == 'claude') {
      return [if (claude != null) claude, if (local != null) local];
    }
    return [if (local != null) local];
  }

  // ---------- chat ----------

  void _jump() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scroll.hasClients) return;
      _scroll.jumpTo(_scroll.position.maxScrollExtent);
    });
  }

  void _poke() {
    if (_loading) return;
    _pokeTimer?.cancel();
    setState(() => _emotion = Emotion.malu);
    _pokeTimer = Timer(const Duration(milliseconds: 1800), () {
      if (mounted && !_loading) setState(() => _emotion = Emotion.kalem);
    });
  }

  Future<void> _send() async {
    final text = _input.text.trim();
    final s = _settings;
    if (text.isEmpty || _loading || s == null) return;

    final chain = _backends(s);
    if (chain.isEmpty) {
      _toast('Unduh model Nala dulu di Pengaturan.');
      await _openSettings();
      return;
    }

    await _voice.stop();
    if (_listening) {
      await _stt.stop();
    }
    _pokeTimer?.cancel();
    if (!mounted) return;

    setState(() {
      _turns.add(ChatTurn('user', text));
      _input.clear();
      _loading = true;
      _started = false;
      _stop = false;
      _listening = false;
      _note = null;
      _activeName = chain.first.name;
    });
    _saveHistory();
    _jump();

    final buf = StringBuffer();
    var started = false;
    var tagged = false;
    var spoken = 0;
    var lastClean = '';
    String? error;

    try {
      for (var i = 0; i < chain.length; i++) {
        final b = chain[i];
        if (mounted) setState(() => _activeName = b.name);
        try {
          await for (final chunk in b.stream(
            List.of(_turns),
            (sec) {
              if (mounted) {
                setState(() =>
                    _note = '${b.name} lagi sibuk, nyoba lagi dalam ${sec}s...');
              }
            },
          )) {
            if (!mounted) return;
            if (_stop) break;
            buf.write(chunk);

            final parsed = parseReply(buf.toString());
            if (parsed.emotion != null && !tagged) {
              tagged = true;
              setState(() => _emotion = parsed.emotion!);
            }
            final clean = parsed.text;
            if (clean.isEmpty) continue;
            lastClean = clean;

            if (clean.length > spoken) {
              _voice.feed(clean.substring(spoken));
              spoken = clean.length;
            }
            setState(() {
              _note = null;
              _started = true;
              if (started) {
                _turns[_turns.length - 1] = ChatTurn('assistant', clean);
              } else {
                _turns.add(ChatTurn('assistant', clean));
                started = true;
              }
            });
            _jump();
          }
          break; // selesai atau dihentikan user
        } on LlmException catch (e) {
          final hasNext = i < chain.length - 1;
          if (!started && e.fallbackWorthy && hasNext) {
            if (mounted) {
              setState(() =>
                  _note = '${b.name} nggak bisa, pindah ke ${chain[i + 1].name}...');
            }
            continue;
          }
          error = e.message;
          break;
        }
      }
    } catch (e) {
      error = e.toString();
    } finally {
      final err = error;
      if (mounted) {
        if (err != null) {
          _voice.stop();
        } else if (!_stop) {
          if (!tagged && lastClean.isNotEmpty) _emotion = guessEmotion(lastClean);
          _voice.finish();
        }
        setState(() {
          _loading = false;
          _started = false;
          _note = null;
          if (err != null) _turns.add(ChatTurn('assistant', err, isError: true));
        });
        _saveHistory();
        _jump();
      }
    }
  }

  void _stopGenerating() {
    setState(() => _stop = true);
    _voice.stop();
  }

  Future<void> _toggleMic() async {
    if (_listening) {
      await _stt.stop();
      if (mounted) setState(() => _listening = false);
      return;
    }
    if (_loading) return;
    await _voice.stop();

    if (!_sttReady) {
      _sttReady = await _stt.initialize(
        onStatus: (status) {
          if ((status == 'done' || status == 'notListening') && mounted) {
            setState(() => _listening = false);
          }
        },
        onError: (e) {
          if (!mounted) return;
          setState(() => _listening = false);
          _toast('Mikrofon bermasalah: ${e.errorMsg}');
        },
      );
    }
    if (!_sttReady) {
      _toast('Izin mikrofon atau pengenalan suara belum tersedia di HP ini.');
      return;
    }

    setState(() => _listening = true);
    await _stt.listen(
      onResult: (r) {
        _input.text = r.recognizedWords;
        _input.selection = TextSelection.collapsed(offset: _input.text.length);
        if (r.finalResult && _input.text.trim().isNotEmpty) {
          setState(() => _listening = false);
          _send();
        }
      },
      localeId: 'id_ID',
      listenFor: const Duration(seconds: 60),
      pauseFor: const Duration(seconds: 3),
      listenOptions: SpeechListenOptions(partialResults: true, cancelOnError: true),
    );
  }

  Future<void> _newChat() async {
    await _voice.stop();
    setState(() {
      _turns.clear();
      _emotion = Emotion.kalem;
    });
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_historyKey);
  }

  bool get _voiceOn => _settings?.voiceOn ?? true;

  bool get _talking =>
      _voiceOn ? _voice.speaking.value : (_loading && _started);

  String get _status {
    if (_note != null) return _note!;
    final s = _settings;
    if (s != null && !_loading && _backends(s).isEmpty) {
      return 'Belum ada model. Buka Pengaturan.';
    }
    final name = _loading
        ? _activeName
        : (s == null || _backends(s).isEmpty ? null : _backends(s).first.name);
    final label = _listening
        ? 'Lagi dengerin...'
        : (_loading && !_started)
            ? 'Lagi mikir...'
            : _talking
                ? 'Lagi ngomong'
                : 'Siap bantu';
    return name == null ? label : '$label · $name';
  }

  // ---------- tampilan ----------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            _stage(),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 2, 16, 6),
              child: Text(
                'Nala  ·  $_status',
                maxLines: 2,
                textAlign: TextAlign.center,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: NalaColors.muted, fontSize: 13),
              ),
            ),
            Expanded(
              child: ListView.builder(
                controller: _scroll,
                padding: const EdgeInsets.fromLTRB(14, 4, 14, 8),
                itemCount: _turns.length + 1,
                itemBuilder: (_, i) => _Bubble(
                  turn: i == 0 ? ChatTurn('assistant', _greeting) : _turns[i - 1],
                ),
              ),
            ),
            _inputBar(),
          ],
        ),
      ),
    );
  }

  Widget _stage() {
    final h = (MediaQuery.of(context).size.height * 0.30).clamp(200.0, 300.0);
    return SizedBox(
      height: h,
      child: Stack(
        alignment: Alignment.bottomCenter,
        children: [
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: const Alignment(0, 0.2),
                  radius: 0.75,
                  colors: [
                    NalaColors.glow.withAlpha(60),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
          NalaAvatar(
            emotion: _emotion,
            talking: _talking,
            thinking: _loading && !_started,
            height: h,
            onTap: _poke,
          ),
          Positioned(
            top: 4,
            right: 4,
            child: Column(
              children: [
                IconButton(
                  tooltip: _voiceOn ? 'Matikan suara' : 'Nyalakan suara',
                  onPressed: _toggleVoice,
                  icon: Icon(
                    _voiceOn ? Icons.volume_up_rounded : Icons.volume_off_rounded,
                    color: NalaColors.muted,
                  ),
                ),
                IconButton(
                  tooltip: 'Pengaturan',
                  onPressed: _loading ? null : _openSettings,
                  icon: const Icon(Icons.tune_rounded, color: NalaColors.muted),
                ),
                IconButton(
                  tooltip: 'Chat baru',
                  onPressed: _loading ? null : _newChat,
                  icon: const Icon(Icons.refresh_rounded, color: NalaColors.muted),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _inputBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 4, 12, 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          IconButton.filledTonal(
            onPressed: _loading ? null : _toggleMic,
            style: IconButton.styleFrom(
              backgroundColor: _listening ? NalaColors.glow : NalaColors.surface,
              foregroundColor: _listening ? NalaColors.bg : NalaColors.text,
            ),
            icon: Icon(_listening ? Icons.mic_rounded : Icons.mic_none_rounded),
            tooltip: _listening ? 'Selesai bicara' : 'Bicara ke Nala',
          ),
          const SizedBox(width: 8),
          Expanded(
            child: TextField(
              controller: _input,
              minLines: 1,
              maxLines: 6,
              textInputAction: TextInputAction.newline,
              decoration: InputDecoration(
                hintText: _listening ? 'Ngomong aja, aku dengerin...' : 'Tanya Nala...',
                filled: true,
                fillColor: NalaColors.surface,
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(22),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          IconButton.filled(
            onPressed: _loading ? _stopGenerating : _send,
            style: IconButton.styleFrom(
              backgroundColor: NalaColors.amber,
              foregroundColor: NalaColors.bg,
            ),
            icon: Icon(_loading ? Icons.stop_rounded : Icons.arrow_upward_rounded),
            tooltip: _loading ? 'Berhenti' : 'Kirim',
          ),
        ],
      ),
    );
  }
}

class _Bubble extends StatelessWidget {
  const _Bubble({required this.turn});
  final ChatTurn turn;

  @override
  Widget build(BuildContext context) {
    final isUser = turn.role == 'user';
    final color = isUser
        ? NalaColors.amber
        : (turn.isError ? const Color(0xFF5A2A3A) : NalaColors.surface);
    final fg = isUser ? NalaColors.bg : NalaColors.text;

    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        constraints:
            BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .88),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(18),
            topRight: const Radius.circular(18),
            bottomLeft: Radius.circular(isUser ? 18 : 4),
            bottomRight: Radius.circular(isUser ? 4 : 18),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: _segments(turn.text, fg),
        ),
      ),
    );
  }

  /// Pecah teks jadi bagian biasa dan blok kode (```...```).
  /// Blok kode yang belum ditutup (masih di-stream) tetap tampil sebagai kode.
  List<Widget> _segments(String text, Color fg) {
    final parts = text.split('```');
    final out = <Widget>[];
    for (var i = 0; i < parts.length; i++) {
      final part = parts[i];
      if (i.isOdd) {
        final nl = part.indexOf('\n');
        final lang = nl > 0 ? part.substring(0, nl).trim() : '';
        final body = (nl >= 0 ? part.substring(nl + 1) : '').trimRight();
        out.add(_CodeBlock(code: body, lang: lang));
      } else if (part.trim().isNotEmpty) {
        out.add(SelectableText(
          part.trim(),
          style: TextStyle(color: fg, fontSize: 15, height: 1.4),
        ));
      }
    }
    return out;
  }
}

class _CodeBlock extends StatelessWidget {
  const _CodeBlock({required this.code, required this.lang});
  final String code;
  final String lang;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: NalaColors.code,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 12, right: 4),
            child: Row(
              children: [
                Text(lang.isEmpty ? 'kode' : lang,
                    style: const TextStyle(color: NalaColors.muted, fontSize: 12)),
                const Spacer(),
                TextButton.icon(
                  onPressed: () {
                    Clipboard.setData(ClipboardData(text: code));
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Kode disalin'),
                        duration: Duration(seconds: 1),
                      ),
                    );
                  },
                  icon: const Icon(Icons.copy_rounded, size: 14),
                  label: const Text('Salin'),
                  style: TextButton.styleFrom(
                    foregroundColor: NalaColors.amber,
                    visualDensity: VisualDensity.compact,
                  ),
                ),
              ],
            ),
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
            child: SelectableText(
              code,
              style: const TextStyle(
                fontFamily: 'monospace',
                fontSize: 13,
                height: 1.4,
                color: NalaColors.text,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

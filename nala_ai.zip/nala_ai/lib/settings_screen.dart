import 'package:flutter/material.dart';

import 'llm.dart';
import 'local_llm.dart';
import 'settings.dart';
import 'theme.dart';
import 'voice.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key, required this.settings});
  final AppSettings settings;

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late AppSettings _s = widget.settings;
  late final _key = TextEditingController(text: _s.claudeKey);
  late final _claudeModel = TextEditingController(text: _s.claudeModel);

  String? _busyId; // model yang lagi diunduh atau dihapus
  int _progress = 0;
  String? _error;

  @override
  void dispose() {
    _key.dispose();
    _claudeModel.dispose();
    super.dispose();
  }

  /// Ambil isi kolom teks ke dalam settings.
  AppSettings _collect() => _s.copyWith(
        claudeKey: _key.text.trim(),
        claudeModel: _claudeModel.text.trim().isEmpty
            ? 'claude-sonnet-5'
            : _claudeModel.text.trim(),
      );

  Future<void> _download(LocalModelSpec spec) async {
    setState(() {
      _busyId = spec.id;
      _progress = 0;
      _error = null;
    });
    try {
      final old = localModelById(_s.installedLocalId);
      if (old != null && old.id != spec.id) {
        await LocalLlm.instance.uninstall(old);
      }
      await LocalLlm.instance.install(
        spec,
        onProgress: (p) {
          if (mounted) setState(() => _progress = p);
        },
      );
      _s = _collect().copyWith(installedLocalId: spec.id, localModelId: spec.id);
      await SettingsStore.save(_s);
    } on LlmException catch (e) {
      _error = e.message;
    } catch (e) {
      _error = e.toString();
    } finally {
      if (mounted) setState(() => _busyId = null);
    }
  }

  Future<void> _remove(LocalModelSpec spec) async {
    setState(() {
      _busyId = spec.id;
      _error = null;
    });
    try {
      await LocalLlm.instance.uninstall(spec);
      _s = _collect().copyWith(clearInstalled: true);
      await SettingsStore.save(_s);
    } catch (e) {
      _error = 'Gagal menghapus model: $e';
    } finally {
      if (mounted) setState(() => _busyId = null);
    }
  }

  Future<void> _save() async {
    final s = _collect();
    await SettingsStore.save(s);
    if (mounted) Navigator.pop(context, s);
  }

  @override
  Widget build(BuildContext context) {
    final busy = _busyId != null;
    return PopScope(
      canPop: !busy,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: NalaColors.bg,
          title: const Text('Pengaturan Nala'),
          actions: [
            TextButton(onPressed: busy ? null : _save, child: const Text('Simpan')),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
          children: [
            _title('Otak Nala'),
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'local', label: Text('Di HP (gratis)')),
                ButtonSegment(value: 'claude', label: Text('Claude')),
              ],
              selected: {_s.engine},
              onSelectionChanged:
                  busy ? null : (v) => setState(() => _s = _s.copyWith(engine: v.first)),
            ),
            const SizedBox(height: 8),
            Text(
              _s.engine == 'local'
                  ? 'Model jalan langsung di HP kamu. Gratis, offline, dan tanpa limit sama sekali.'
                  : 'Claude lebih pintar tapi ada limit dan saldo. Kalau kena limit, Nala otomatis pindah ke model di HP (kalau sudah diunduh).',
              style: const TextStyle(color: NalaColors.muted, fontSize: 13),
            ),
            const SizedBox(height: 24),
            _title('Model di HP'),
            const Text(
              'Unduh sekali lewat Wi-Fi. Setelah itu Nala jalan tanpa internet.',
              style: TextStyle(color: NalaColors.muted, fontSize: 13),
            ),
            const SizedBox(height: 8),
            for (final m in localModels) _modelCard(m, busy),
            if (_error != null)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(_error!,
                    style: const TextStyle(color: Color(0xFFFF8FA3))),
              ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Pakai GPU'),
              subtitle: const Text(
                'Lebih cepat. Matikan kalau HP kamu hang atau panas saat Nala menjawab.',
                style: TextStyle(color: NalaColors.muted, fontSize: 12),
              ),
              value: _s.useGpu,
              onChanged: busy ? null : (v) => setState(() => _s = _s.copyWith(useGpu: v)),
            ),
            const SizedBox(height: 16),
            _title('Suara Nala'),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Nala bicara pakai suara'),
              subtitle: const Text(
                'Memakai suara bawaan HP. Kode tidak dibacakan.',
                style: TextStyle(color: NalaColors.muted, fontSize: 12),
              ),
              value: _s.voiceOn,
              onChanged: busy ? null : (v) => setState(() => _s = _s.copyWith(voiceOn: v)),
            ),
            const Text('Kecepatan bicara', style: TextStyle(fontSize: 13)),
            Slider(
              value: _s.voiceRate,
              min: 0.3,
              max: 0.7,
              activeColor: NalaColors.amber,
              onChanged: (v) => setState(() => _s = _s.copyWith(voiceRate: v)),
            ),
            const Text('Nada suara (makin tinggi makin imut)',
                style: TextStyle(fontSize: 13)),
            Slider(
              value: _s.voicePitch,
              min: 0.8,
              max: 1.6,
              activeColor: NalaColors.amber,
              onChanged: (v) => setState(() => _s = _s.copyWith(voicePitch: v)),
            ),
            Align(
              alignment: Alignment.centerLeft,
              child: OutlinedButton.icon(
                onPressed: () => NalaVoice.instance.test(_s.voiceRate, _s.voicePitch),
                icon: const Icon(Icons.volume_up_rounded, size: 18),
                label: const Text('Coba suara'),
              ),
            ),
            const SizedBox(height: 4),
            const Text(
              'Kalau suaranya nggak keluar atau bukan bahasa Indonesia: buka Pengaturan Android, cari "Text-to-speech", lalu pilih Google dan unduh suara Bahasa Indonesia.',
              style: TextStyle(color: NalaColors.muted, fontSize: 12),
            ),
            const SizedBox(height: 20),
            _title('Claude (opsional)'),
            const SizedBox(height: 4),
            TextField(
              controller: _key,
              obscureText: true,
              autocorrect: false,
              decoration: const InputDecoration(
                labelText: 'API key Claude',
                helperText: 'Dari console.anthropic.com. Disimpan terenkripsi di HP.',
              ),
            ),
            TextField(
              controller: _claudeModel,
              autocorrect: false,
              decoration: const InputDecoration(labelText: 'Nama model Claude'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _title(String t) => Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Text(t,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
      );

  Widget _modelCard(LocalModelSpec m, bool busy) {
    final installed = _s.installedLocalId == m.id;
    final thisBusy = _busyId == m.id;
    return Card(
      color: NalaColors.surface,
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text('${m.name}  ·  ${m.sizeLabel}',
                      style: const TextStyle(fontWeight: FontWeight.w600)),
                ),
                if (installed)
                  const Chip(
                    label: Text('Terpasang'),
                    visualDensity: VisualDensity.compact,
                  ),
              ],
            ),
            const SizedBox(height: 4),
            Text(m.note,
                style: const TextStyle(color: NalaColors.muted, fontSize: 13)),
            const SizedBox(height: 10),
            if (thisBusy && !installed || (thisBusy && _progress > 0 && _progress < 100))
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  LinearProgressIndicator(
                    value: _progress > 0 ? _progress / 100 : null,
                    color: NalaColors.amber,
                  ),
                  const SizedBox(height: 6),
                  Text(
                    _progress > 0
                        ? 'Mengunduh $_progress%. Jangan tutup app dulu.'
                        : 'Menyiapkan...',
                    style: const TextStyle(color: NalaColors.muted, fontSize: 12),
                  ),
                ],
              )
            else if (installed)
              OutlinedButton(
                onPressed: busy ? null : () => _remove(m),
                child: const Text('Hapus dari HP'),
              )
            else
              FilledButton(
                onPressed: busy ? null : () => _download(m),
                style: FilledButton.styleFrom(
                  backgroundColor: NalaColors.amber,
                  foregroundColor: NalaColors.bg,
                ),
                child: const Text('Unduh'),
              ),
          ],
        ),
      ),
    );
  }
}

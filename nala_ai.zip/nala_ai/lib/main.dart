import 'package:flutter/material.dart';
import 'package:flutter_gemma/flutter_gemma.dart';
import 'package:flutter_gemma_litertlm/flutter_gemma_litertlm.dart';

import 'chat_screen.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Daftarkan engine yang menjalankan model .litertlm langsung di HP.
  await FlutterGemma.initialize(
    inferenceEngines: const [LiteRtLmEngine()],
    maxDownloadRetries: 10,
  );

  runApp(const NalaApp());
}

class NalaApp extends StatelessWidget {
  const NalaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Nala',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: NalaColors.bg,
        colorScheme: const ColorScheme.dark(
          primary: NalaColors.amber,
          surface: NalaColors.surface,
        ),
        textTheme: ThemeData.dark().textTheme.apply(
              bodyColor: NalaColors.text,
              displayColor: NalaColors.text,
            ),
      ),
      home: const ChatScreen(),
    );
  }
}

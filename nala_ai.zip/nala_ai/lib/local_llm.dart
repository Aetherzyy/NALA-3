import 'package:flutter_gemma/flutter_gemma.dart';

import 'llm.dart';

/// Konteks model (total token untuk riwayat + jawaban).
const _contextTokens = 4096;

/// Batas riwayat yang dikirim ke model di HP (karakter). Disisakan ruang
/// untuk jawaban di dalam konteks 4096 token.
const _historyChars = 4000;

class LocalModelSpec {
  const LocalModelSpec({
    required this.id,
    required this.name,
    required this.sizeLabel,
    required this.note,
    required this.url,
    required this.type,
  });

  final String id;
  final String name;
  final String sizeLabel;
  final String note;
  final String url;
  final ModelType type;

  String get fileName => url.split('/').last;
}

const localModels = [
  LocalModelSpec(
    id: 'gemma4',
    name: 'Gemma 4 E2B',
    sizeLabel: '2,6 GB',
    note: 'Lebih pintar, cocok buat coding. Sebaiknya HP dengan RAM 6 GB ke atas.',
    url:
        'https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm/resolve/main/gemma-4-E2B-it.litertlm',
    type: ModelType.gemma4,
  ),
  LocalModelSpec(
    id: 'qwen3',
    name: 'Qwen3 0.6B',
    sizeLabel: '0,6 GB',
    note: 'Ringan dan cepat, buat HP dengan RAM kecil. Jawabannya lebih sederhana.',
    url:
        'https://huggingface.co/litert-community/Qwen3-0.6B/resolve/main/Qwen3-0.6B.litertlm',
    type: ModelType.qwen3,
  ),
];

LocalModelSpec? localModelById(String? id) {
  for (final m in localModels) {
    if (m.id == id) return m;
  }
  return null;
}

/// Model AI yang jalan langsung di HP. Setelah diunduh sekali, semuanya offline:
/// gratis, tanpa kuota, tanpa limit.
class LocalLlm {
  LocalLlm._();
  static final instance = LocalLlm._();

  dynamic _model;
  bool _modelGpu = true;

  /// Unduh dan pasang model. [onProgress] menerima 0 sampai 100.
  Future<void> install(
    LocalModelSpec spec, {
    required void Function(int percent) onProgress,
  }) async {
    await release();
    try {
      await FlutterGemma.installModel(
        modelType: spec.type,
        fileType: ModelFileType.litertlm,
      )
          .fromNetwork(spec.url, foreground: true)
          .withProgress((p) => onProgress(p))
          .install();
    } on DownloadException catch (e) {
      throw LlmException(e.error.toUserMessage());
    } catch (e) {
      throw LlmException('Gagal mengunduh model: $e');
    }
  }

  Future<void> uninstall(LocalModelSpec spec) async {
    await release();
    await FlutterGemma.uninstallModel(spec.fileName);
    await FlutterGemma.clearActiveInferenceIdentity();
  }

  /// Lepas model dari memori.
  Future<void> release() async {
    final m = _model;
    _model = null;
    if (m != null) {
      try {
        await m.close();
      } catch (_) {}
    }
  }

  int _ctx = _contextTokens;

  /// Batas riwayat (karakter) menyesuaikan ukuran konteks yang berhasil dimuat.
  int get _budget => ((_ctx - 900) * 2.5).round().clamp(600, _historyChars);

  String _short(Object e) {
    final s = e.toString().replaceAll('\n', ' ');
    return s.length > 150 ? '${s.substring(0, 150)}...' : s;
  }

  /// Muat model. Kalau gagal, coba kombinasi lain: GPU lalu CPU, dan ukuran
  /// konteks 4096, 2048, lalu 1024. Semua alasan gagalnya dikumpulkan supaya
  /// penyebabnya bisa dilihat.
  Future<dynamic> _ensureModel(bool useGpu) async {
    if (_model != null && _modelGpu == useGpu) return _model;
    await release();
    final errors = <String>[];
    for (final gpu in useGpu ? [true, false] : [false]) {
      for (final tokens in const [_contextTokens, 2048, 1024]) {
        try {
          _model = await FlutterGemma.getActiveModel(
            maxTokens: tokens,
            preferredBackend: gpu ? PreferredBackend.gpu : PreferredBackend.cpu,
          );
          _modelGpu = useGpu;
          _ctx = tokens;
          return _model;
        } catch (e) {
          errors.add('${gpu ? 'GPU' : 'CPU'}, konteks $tokens: ${_short(e)}');
        }
      }
    }
    throw LlmException(
      'Model di HP gagal dimuat. Coba hapus lalu unduh ulang modelnya di Pengaturan '
      '(pastikan penyimpanan lega), atau pakai mode Claude.\n\n'
      'Detail:\n${errors.join('\n')}',
    );
  }

  /// Susun seluruh percakapan jadi satu prompt. Sengaja tanpa state di sisi
  /// model, jadi riwayat yang tersimpan tetap nyambung setelah app ditutup.
  String _buildPrompt(List<ChatTurn> history) {
    final turns = history.where((t) => !t.isError).toList();
    final lines = <String>[];
    var used = 0;
    for (var i = turns.length - 1; i >= 0; i--) {
      var text = turns[i].text;
      final label = turns[i].role == 'user' ? 'User' : 'Nala';
      final room = _budget - used;
      if (text.length > room) {
        if (lines.isNotEmpty) break;
        text = text.substring(text.length - room);
      }
      lines.add('$label: $text');
      used += text.length;
    }
    return '$systemPrompt\n\n'
        'Percakapan sejauh ini:\n${lines.reversed.join('\n\n')}\n\n'
        'Tulis balasan Nala untuk pesan User yang terakhir. '
        'Mulai dengan satu tag emosi (misalnya [senang]), lalu langsung isi '
        'jawabannya, tanpa awalan "Nala:".';
  }

  Stream<String> stream(List<ChatTurn> history, {required bool useGpu}) async* {
    final model = await _ensureModel(useGpu);
    final chat = await model.openChat();
    var finished = false;
    try {
      await chat.addQueryChunk(
        Message.text(text: _buildPrompt(history), isUser: true),
      );
      await for (final r in chat.generateChatResponseAsync()) {
        if (r is TextResponse) yield r.token;
      }
      finished = true;
    } finally {
      if (!finished) {
        // dihentikan user: minta model berhenti menghasilkan token
        try {
          await (chat as dynamic).stopGeneration();
        } catch (_) {}
      }
      try {
        await chat.session.close();
      } catch (_) {}
    }
  }
}

import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import 'emotion.dart';

const _frameNames = [
  'idle',
  'mouth_small',
  'mouth_wide',
  'tongue',
  'wink_l',
  'wink_r',
  'pout',
  'shy',
  'blink',
  'smile',
];

String _asset(String name) => 'assets/nala/$name.webp';

/// Avatar anime Nala. Frame diganti sesuai keadaan:
/// bicara (mulut membuka dan menutup), mikir, emosi, kedip, dan wink iseng.
class NalaAvatar extends StatefulWidget {
  const NalaAvatar({
    super.key,
    required this.emotion,
    required this.talking,
    this.thinking = false,
    this.height = 260,
    this.onTap,
  });

  final Emotion emotion;
  final bool talking;
  final bool thinking;
  final double height;
  final VoidCallback? onTap;

  @override
  State<NalaAvatar> createState() => _NalaAvatarState();
}

class _NalaAvatarState extends State<NalaAvatar>
    with SingleTickerProviderStateMixin {
  late final Ticker _ticker;
  int _ms = 0;
  int _lastPaint = -100;
  bool _precached = false;

  @override
  void initState() {
    super.initState();
    _ticker = createTicker((d) {
      _ms = d.inMilliseconds;
      if (_ms - _lastPaint >= 33) {
        _lastPaint = _ms;
        if (mounted) setState(() {});
      }
    })..start();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_precached) return;
    _precached = true;
    for (final n in _frameNames) {
      precacheImage(AssetImage(_asset(n)), context);
    }
  }

  @override
  void dispose() {
    _ticker.dispose();
    super.dispose();
  }

  /// Wajah saat mulut tertutup, sesuai emosi.
  String _closedFor(Emotion e) => switch (e) {
        Emotion.kalem => 'idle',
        Emotion.senang => 'smile',
        Emotion.jahil => 'smile',
        Emotion.malu => 'shy',
        Emotion.kesal => 'pout',
      };

  /// Wajah saat diam, sesuai emosi.
  String _restFor(Emotion e, int ms) => switch (e) {
        Emotion.kalem => 'smile',
        Emotion.senang => (ms % 3000) < 900 ? 'mouth_wide' : 'smile',
        Emotion.jahil => (ms ~/ 1600).isEven ? 'tongue' : 'smile',
        Emotion.malu => 'shy',
        Emotion.kesal => 'pout',
      };

  String _pick(int ms) {
    final e = widget.emotion;
    final blinking = ms % 4200 >= 4060; // kedip tiap 4,2 detik selama 140 ms

    if (widget.talking) {
      if (blinking) return 'blink';
      const seq = ['c', 's', 'w', 's', 'c', 's', 's', 'w'];
      switch (seq[(ms ~/ 130) % seq.length]) {
        case 's':
          return 'mouth_small';
        case 'w':
          return 'mouth_wide';
        default:
          return _closedFor(e);
      }
    }
    if (blinking) return 'blink';
    if (widget.thinking) return 'idle';

    // wink iseng sesekali kalau suasananya santai
    if (e == Emotion.kalem || e == Emotion.senang) {
      final p = ms % 12000;
      if (p >= 11000) return (ms ~/ 12000).isEven ? 'wink_l' : 'wink_r';
    }
    return _restFor(e, ms);
  }

  @override
  Widget build(BuildContext context) {
    const visible = 0.62; // bagian atas gambar yang ditampilkan (kepala sampai dasi)
    final h = widget.height;
    final imgH = h / visible;
    final imgW = imgH * 0.5;

    final breath = 1 + 0.008 * math.sin(_ms / 1000 * 2 * math.pi / 3.8);
    final bob = widget.talking ? math.sin(_ms / 90) * 1.2 : 0.0;

    return GestureDetector(
      onTap: widget.onTap,
      child: SizedBox(
        width: imgW,
        height: h,
        child: ClipRect(
          child: Align(
            alignment: Alignment.topCenter,
            heightFactor: visible,
            child: Transform.translate(
              offset: Offset(0, bob),
              child: Transform.scale(
                scale: breath,
                alignment: Alignment.topCenter,
                child: Image.asset(
                  _asset(_pick(_ms)),
                  width: imgW,
                  height: imgH,
                  fit: BoxFit.fill,
                  gaplessPlayback: true,
                  filterQuality: FilterQuality.medium,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

import 'dart:convert';
import 'package:http/http.dart' as http;

import 'llm.dart';

const _claudeMaxOutput = 16000;
const _claudeHistoryChars = 350000;
const _retryable = {429, 500, 502, 503, 529};

/// Mengalirkan jawaban Claude potongan demi potongan.
/// Kalau server bilang terlalu banyak request atau lagi sibuk, otomatis menunggu
/// lalu mencoba lagi (sampai 5 kali). Kalau tetap gagal karena limit atau saldo,
/// melempar [LlmException] dengan fallbackWorthy = true supaya Nala pindah ke
/// model di HP.
Stream<String> streamClaude({
  required String apiKey,
  required String model,
  required List<ChatTurn> history,
  void Function(int seconds)? onRetry,
}) async* {
  final messages = prepareMessages(history, _claudeHistoryChars);
  final client = http.Client();
  try {
    late http.StreamedResponse res;
    for (var attempt = 0;; attempt++) {
      final req = http.Request(
        'POST',
        Uri.parse('https://api.anthropic.com/v1/messages'),
      )
        ..headers.addAll({
          'content-type': 'application/json',
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01',
        })
        ..body = jsonEncode({
          'model': model,
          'max_tokens': _claudeMaxOutput,
          'system': systemPrompt,
          'messages': messages,
          'stream': true,
        });

      http.StreamedResponse r;
      try {
        r = await client.send(req).timeout(const Duration(seconds: 60));
      } catch (_) {
        throw LlmException(
          'Nggak bisa nyambung ke Claude. Cek koneksi internet kamu.',
          fallbackWorthy: true,
        );
      }
      if (r.statusCode == 200) {
        res = r;
        break;
      }

      final text = await r.stream.bytesToString();
      final code = r.statusCode;

      if (_retryable.contains(code) && attempt < 5) {
        final wait = int.tryParse(r.headers['retry-after'] ?? '') ?? (2 << attempt);
        onRetry?.call(wait);
        await Future.delayed(Duration(seconds: wait));
        continue;
      }

      String? msg;
      try {
        msg = jsonDecode(text)['error']?['message']?.toString();
      } catch (_) {}

      if (code == 401 || code == 403) {
        throw LlmException('API key Claude ditolak. Cek lagi di Pengaturan.');
      }
      if (code == 402 || code == 429) {
        throw LlmException('Claude kena limit atau saldo habis.', fallbackWorthy: true);
      }
      throw LlmException(msg ?? 'Claude error $code.', fallbackWorthy: code >= 500);
    }

    await for (final line
        in res.stream.transform(utf8.decoder).transform(const LineSplitter())) {
      if (!line.startsWith('data:')) continue;
      final payload = line.substring(5).trim();
      if (payload.isEmpty) continue;
      final j = jsonDecode(payload);
      if (j['type'] == 'content_block_delta' &&
          j['delta']?['type'] == 'text_delta') {
        yield j['delta']['text'] as String;
      } else if (j['type'] == 'error') {
        throw LlmException(j['error']?['message']?.toString() ?? 'Stream terputus.');
      }
    }
  } finally {
    client.close();
  }
}

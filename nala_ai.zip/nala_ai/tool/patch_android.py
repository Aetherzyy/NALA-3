"""Menyesuaikan project Android hasil `flutter create` untuk Nala.
- minSdk 26
- hanya arm64-v8a (yang didukung engine model di HP)
- izin internet + izin unduhan model besar di Android 14+
"""
import pathlib
import re
import sys

app = pathlib.Path('android/app')

gradle = next((p for p in (app / 'build.gradle.kts', app / 'build.gradle') if p.exists()), None)
if gradle is None:
    sys.exit('build.gradle tidak ditemukan')
s = gradle.read_text()
kts = gradle.suffix == '.kts'

if kts:
    s, n = re.subn(r'minSdk\s*=\s*[^\n]+', 'minSdk = 26', s)
else:
    s, n = re.subn(r'minSdkVersion\s+[^\n]+', 'minSdkVersion 26', s)
    if n == 0:
        s, n = re.subn(r'minSdk\s+[^\n]+', 'minSdk 26', s)
if n == 0:
    sys.exit('minSdk tidak ditemukan di ' + str(gradle))

ndk = 'ndk { abiFilters += "arm64-v8a" }' if kts else "ndk { abiFilters 'arm64-v8a' }"
s, n = re.subn(r'defaultConfig\s*\{', lambda m: m.group(0) + '\n        ' + ndk, s, count=1)
if n == 0:
    sys.exit('defaultConfig tidak ditemukan di ' + str(gradle))
gradle.write_text(s)

mf = app / 'src/main/AndroidManifest.xml'
m = mf.read_text()
if 'xmlns:tools' not in m:
    m = m.replace('<manifest ', '<manifest xmlns:tools="http://schemas.android.com/tools" ', 1)

perms = (
    '    <uses-permission android:name="android.permission.INTERNET"/>\n'
    '    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>\n'
    '    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>\n'
    '    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_DATA_SYNC"/>\n'
    '    <uses-permission android:name="android.permission.RECORD_AUDIO"/>\n'
)
intents = (
    '        <intent><action android:name="android.intent.action.TTS_SERVICE"/></intent>\n'
    '        <intent><action android:name="android.speech.RecognitionService"/></intent>\n'
)
if '<queries>' in m:
    m = m.replace('<queries>', '<queries>\n' + intents, 1)
else:
    perms += '    <queries>\n' + intents + '    </queries>\n'
m = m.replace('<application', perms + '    <application', 1)

svc = (
    '\n        <service android:name="androidx.work.impl.foreground.SystemForegroundService"'
    ' android:foregroundServiceType="dataSync" tools:node="merge"/>'
)
m, n = re.subn(r'(<application\b[^>]*>)', lambda x: x.group(1) + svc, m, count=1)
if n == 0:
    sys.exit('tag application tidak ditemukan')
mf.write_text(m)
print('Android config sudah disesuaikan.')

# Pakai kunci tanda tangan yang tetap, supaya update APK berikutnya bisa
# dipasang di atas versi lama tanpa uninstall (data dan model tetap aman).
import shutil
ks_src = pathlib.Path('tool/debug.keystore')
if ks_src.exists():
    dest = pathlib.Path.home() / '.android'
    dest.mkdir(parents=True, exist_ok=True)
    shutil.copy(ks_src, dest / 'debug.keystore')
    print('Kunci tanda tangan tetap dipasang.')

# Nala, asisten coding di HP (jalan offline, gratis, tanpa limit)

App Flutter untuk Android dengan karakter AI bernama Nala. Otaknya adalah model AI yang
**jalan langsung di dalam HP kamu** lewat paket `flutter_gemma` (LiteRT-LM). Nggak perlu PC,
Termux, server, atau API key. Setelah model diunduh sekali, Nala jalan tanpa internet,
tanpa biaya, dan tanpa kuota atau limit.

Claude tetap ada sebagai pilihan opsional. Kalau kamu pilih Claude lalu kena limit atau
saldo habis, Nala otomatis pindah ke model di HP.

## Versi 2: avatar anime, suara, dan mikrofon

- Avatar anime Nala (10 frame di `assets/nala/`): mulut bergerak saat bicara, berkedip, mikir, wink iseng, dan ekspresi senang, jahil, malu, atau cemberut sesuai isi jawaban. Tap avatarnya buat bikin dia malu.
- Suara: Nala mengucapkan jawaban per kalimat memakai suara text-to-speech bawaan Android (gratis, offline kalau suara Bahasa Indonesia sudah terunduh). Blok kode tidak dibacakan. Kecepatan dan nada bisa diatur di Pengaturan.
- Mikrofon: tekan ikon mik, ngomong, lalu jawaban Nala otomatis dikirim. Pengenalan suara Bahasa Indonesia di Android biasanya butuh internet.
- Kepribadian: hangat dan perhatian seperti pacar, tetap jago coding. Ada di `systemPrompt` di `lib/llm.dart`.
- Suara Indonesia belum keluar? Buka Pengaturan Android, cari "Text-to-speech", pilih mesin Google, lalu unduh suara Bahasa Indonesia.

## Update aplikasi

1. Upload `nala_ai.zip` baru ke repo GitHub (Add file, Upload files, nama file harus sama, lalu Commit). Build jalan otomatis.
2. Ambil `app-release.apk` dari Releases dan pasang.
3. Kunci tanda tangan sekarang tetap (`tool/debug.keystore`), jadi update berikutnya bisa dipasang langsung di atas versi lama tanpa menghapus data. Khusus update pertama ini, versi lama harus di-uninstall dulu karena kuncinya beda.

## Model yang tersedia

| Model | Ukuran | Cocok untuk |
|---|---|---|
| Gemma 4 E2B | 2,6 GB | Coding dan ngobrol. Sebaiknya HP dengan RAM 6 GB ke atas |
| Qwen3 0.6B | 0,6 GB | HP dengan RAM kecil. Ringan, tapi jawabannya lebih sederhana |

Keduanya lisensi terbuka dan bisa diunduh tanpa akun. Unduhan dilakukan dari dalam app
(Pengaturan, lalu tombol Unduh). Pakai Wi-Fi, ukurannya besar.

## Cara pasang

1. Pastikan Flutter terinstal (`flutter --version`).
2. `flutter create nala_ai`, lalu ganti `pubspec.yaml` dan seluruh isi folder `lib/` dengan file dari sini.
3. Edit `android/app/build.gradle` (atau `build.gradle.kts`):
   - `minSdk` = 26
   - batasi ke arsitektur yang didukung engine:
     ```gradle
     defaultConfig {
         ndk { abiFilters 'arm64-v8a' }
     }
     ```
     (di `.kts`: `ndk { abiFilters += "arm64-v8a" }`)
4. Edit `android/app/src/main/AndroidManifest.xml`:
   ```xml
   <manifest xmlns:android="http://schemas.android.com/apk/res/android"
       xmlns:tools="http://schemas.android.com/tools">

       <uses-permission android:name="android.permission.INTERNET"/>
       <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
       <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
       <uses-permission android:name="android.permission.FOREGROUND_SERVICE_DATA_SYNC"/>

       <application ...>
           <!-- wajib untuk unduhan model besar di Android 14+ -->
           <service
               android:name="androidx.work.impl.foreground.SystemForegroundService"
               android:foregroundServiceType="dataSync"
               tools:node="merge" />
           ...
       </application>
   </manifest>
   ```
5. `flutter pub get`, lalu sambungkan HP (jangan pakai emulator, butuh GPU asli) dan `flutter run`.
6. Di app: ikon slider, tekan **Unduh** pada model, tunggu selesai, lalu tekan **Simpan**.

APK: `flutter build apk --release`

## Catatan jujur

- Model di HP lebih kecil dari Claude, jadi untuk masalah coding yang rumit jawabannya bisa kurang tepat. Untuk pertanyaan sehari-hari, potongan kode, dan penjelasan error, hasilnya cukup bagus.
- Kecepatan tergantung HP. Di HP flagship, Gemma 4 E2B menghasilkan puluhan token per detik. Di HP kelas menengah bisa jauh lebih lambat.
- Menjalankan AI memakai baterai dan bikin HP hangat. Kalau HP hang atau sangat panas, matikan "Pakai GPU" di Pengaturan atau pakai Qwen3 0.6B.
- Nala mengingat sekitar 5000 karakter percakapan terakhir saat pakai model di HP (konteks model kecil terbatas). Riwayat chat tetap tersimpan utuh di layar. Batasnya ada di `lib/local_llm.dart` (`_historyChars`, `_contextTokens`).
- Kode ini belum diuji di perangkat asli. Kalau ada error saat build atau saat memuat model, kirim pesan errornya untuk diperbaiki.

## File penting

- `lib/local_llm.dart`: katalog model di HP, unduh, hapus, dan streaming jawaban.
- `lib/claude_client.dart`: client Claude opsional dengan auto-retry.
- `lib/llm.dart`: kepribadian Nala (`systemPrompt`).
- `lib/nala_avatar.dart`: tampilan karakter.
